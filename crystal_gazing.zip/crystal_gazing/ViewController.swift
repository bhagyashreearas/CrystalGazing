//
//  ViewController.swift
//  crystal_gazing
//
//  Created by Bao Tran on 11/6/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

